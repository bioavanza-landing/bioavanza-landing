
BioAvanza - Landing Page (Junta+)

Como publicar no GitHub Pages:
1) Faça upload dos arquivos deste ZIP para a raiz do seu repositório.
2) Garanta que este arquivo exista: index.html (na raiz).
3) Em Settings -> Pages, configure 'Branch: main' e 'Pasta: /(root)' e salve.
4) Aguarde alguns minutos e acesse: https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/

Dica: se seu repositório for 'bioavanza-landing', e seu usuário for 'bioavanza',
o link ficará: https://bioavanza.github.io/bioavanza-landing/
